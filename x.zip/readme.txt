tutorial menggunakan script:
1. Sebelum menjalankan script buat file format txt dg nama terserah anda,, contoh file a.txt
2. isi file trsebut dg contoh seperti ini:
  /start https://t.me/OutterFinanceAirdropBot?start=1101438607
3. buka termux
4. install modul dg cara ketik dibawah ini:
   pip install telethon
   pip install requests
   pip install random
   pip install colorama
   pip install unicodedata2
   pip install emoji
   pip install func_timeout
   pip install anticaptchaofficial
   
5. buka script yg ada di penyimpanan device dg cara ketik dibawah ini:
   cd /sdcard/namafolderpenyimpananscript
   ls
6. kemudian jalankan script dg cara ketik dibawah ini:
   python join.py -i a.txt
   atau
   python join.py -i a.txt -m 1 - a 1

keterangan :
klo punya akun gmail, discord, twitter, facebook, ig, medium, wallet address,,buatkan file disimpan di satu folder dg script,,file dikasih nama seperti ini:
gmail.txt
discord.txt
twitter.txt
facebook.txt
ig.txt
medium.txt
bsc.txt
sol.txt
trx.txt
dgb.txt

